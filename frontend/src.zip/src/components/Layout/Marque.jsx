import React from 'react'
import slliderlogo1 from "../../assets/images/sllider-logo/1.png"
import slliderlogo2 from "../../assets/images/sllider-logo/2.jpg"
import slliderlogo3 from "../../assets/images/sllider-logo/3.jpg"
import slliderlogo4 from "../../assets/images/sllider-logo/4.jpg"
import slliderlogo5 from "../../assets/images/sllider-logo/5.jpg"
import slliderlogo6 from "../../assets/images/sllider-logo/6.jpg"
import slliderlogo7 from "../../assets/images/sllider-logo/7.jpg"
import slliderlogo8 from "../../assets/images/sllider-logo/8.jpg"
import slliderlogo9 from "../../assets/images/sllider-logo/9.jpg"
import slliderlogo10 from "../../assets/images/sllider-logo/10.jpg"
import slliderlogo11 from "../../assets/images/sllider-logo/11.jpg"
import slliderlogo12 from "../../assets/images/sllider-logo/12.jpg"
import slliderlogo13 from "../../assets/images/sllider-logo/13.jpg"
import slliderlogo14 from "../../assets/images/sllider-logo/14.jpg"
import slliderlogo15 from "../../assets/images/sllider-logo/15.jpg"
import slliderlogo16 from "../../assets/images/sllider-logo/16.jpg"
import slliderlogo17 from "../../assets/images/sllider-logo/17.jpg"
import slliderlogo18 from "../../assets/images/sllider-logo/18.jpg"
import slliderlogo19 from "../../assets/images/sllider-logo/19.jpg"


const Marque = () => {
    return (
        <div>
        
            <div className="Marquee py-5">
                <div className="Marquee-content">
                    <div className="Marquee-tag"><img src={slliderlogo1} alt width="300px" /></div>
                    <div className="Marquee-tag"><img src={slliderlogo2} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo3} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo4} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo5} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo6} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo7} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo8} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo9} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo10} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo11} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo12} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo13} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo14} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo15} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo16} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo17} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo18} alt /></div>
                    <div className="Marquee-tag"><img src={slliderlogo19} alt /></div>
                </div>
            </div>
        </div>

    )
}

export default Marque